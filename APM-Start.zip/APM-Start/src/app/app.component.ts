import { Component } from '@angular/core';
import {smsService} from './sms/sms.service';

import{loginService} from './loginpage/loginservice';
import { frgtService } from './forgotpassword/forgotpassword.service';
import { ChangePasswordService } from './changepassword/changepassword.service';

@Component({
  selector: 'app-root',

  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[smsService,loginService,frgtService,ChangePasswordService]
})
export class AppComponent {
 
}
