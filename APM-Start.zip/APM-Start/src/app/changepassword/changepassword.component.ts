import { Component, OnInit } from '@angular/core';
import { ChangePassword } from './changepassword';
import{ChangePasswordService} from './changepassword.service';
@Component({
  selector: 'pm-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  public pageTitle : string ='changepassword';
  chngpsswd=new ChangePassword();
  oldpasswd:string;
  newpsswd:string;
  userid:number;
  constructor(private chngepsswdService:ChangePasswordService) { }

  ngOnInit() {
  }

  changePsswd(userid,newpsswd,oldpasswd){
    this.postPassword(userid,newpsswd,oldpasswd);
  }
  postPassword(userid,newpsswd,oldpasswd):void{
    this.chngepsswdService.postPasswd(this.userid,this.newpsswd,this.oldpasswd).subscribe();
      
  }
}
