import { Injectable } from "@angular/core";

import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";
import { Sms } from "./sms";

const httpOptions ={
headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class smsService{
private postsms='http://localhost:8089/api/msg';
private sms:Sms[];
constructor(private _http:HttpClient){

} 
 
postSms(sms:Sms):Observable<Sms>
{
return this._http.post<Sms>(this.postsms,sms,{})
} 
 
}