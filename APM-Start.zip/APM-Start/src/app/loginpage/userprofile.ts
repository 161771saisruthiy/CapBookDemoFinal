export class UserProfile{
     userId:number;
	 userName:string;
	 address:any;
     isPrivateDob:boolean;
	dob:Date;
    isPrivateAreaofIntrest:boolean;
	areaofInterest:string;
     albums:any;
     isPrivategender:boolean;
	  gender:boolean;
      mobileNo:string;
	 isPrivateMobileNo:boolean;
     groups:any;
	
     status:any;
     chat:any;
	

     email:string;
	 isPrivateEmail:boolean;
	
}