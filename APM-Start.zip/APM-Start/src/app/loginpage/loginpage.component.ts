import { Component, OnInit } from '@angular/core';

import { Login } from './login';
import { loginService } from './loginservice';
import { UserProfile } from './userprofile';
import { ChangePassword } from './changePassword';



@Component({
  selector: 'pm-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  flag: boolean = false
  lName: string
  fName: string
  email: string;
  login: Login = new Login();
  userprofile: UserProfile = new UserProfile();
  password: ChangePassword = new ChangePassword();
  constructor(private lgnservice: loginService) { }

  ngOnInit() {

  }
  submit(): void {

    this.postUser();
    this.postLogin();
    this.postPassword();



  }
  postPassword(): void {
    this.lgnservice.changePaswd(this.password).subscribe(password => this.password)
  }
  postLogin(): void {
    this.password.oldPassword = this.login.password;
    this.lgnservice.postLgn(this.login).subscribe(login => this.login)
  }
  postUser(): void {
    this.userprofile.userName = this.fName + this.lName
    this.password.emailId = this.userprofile.email;

    this.login.email = this.userprofile.email;
    this.lgnservice.postuser(this.userprofile).subscribe(login => this.userprofile)
  }


}
