import { Injectable } from "@angular/core";

import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";
import { Login} from "./login";
import {UserProfile} from "./userprofile"
import { ChangePassword } from "./changePassword";

const httpOptions ={
headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class loginService{
private postlogin='http://localhost:8083/profileCreation/login';
private postUser='http://localhost:8083/profileCreation/profile';
private changepsswd='http://localhost:8083/profileCreation/changepwd';
private getLoginUrl='http://localhost:8083/profileCreation/EmailNPwd';
private forgotpassword='http://localhost:8083/forgetPwd/passwd/email';
private login:Login;
private uprofile:UserProfile[];


constructor(private _http:HttpClient){

} 
 
postLgn(login1:Login):Observable<Login>
{

return this._http.post<Login>(this.postlogin,login1,{})
} 
 
postuser(userp:UserProfile):Observable<UserProfile>
{


return this._http.post<UserProfile>(this.postUser,userp,{})
} 

changePaswd(password:ChangePassword):Observable<ChangePassword>
{
return this._http.post<ChangePassword>(this.changepsswd,password,{})
} 


getLogin(login:Login):Observable<Login[]>{
    console.log("in service")
    this.getLoginUrl=this.getLoginUrl+'/'+login.email+'/'+login.password
    console.log(login.email+"in service")
    return this._http.get<Login[]>(this.getLoginUrl)
   

}
}