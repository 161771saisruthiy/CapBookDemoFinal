import { Component, OnInit } from '@angular/core';
import { Email } from './email';
import { frgtService } from './forgotpassword.service';
import { Login } from '../loginpage/login';

@Component({
  // selector: 'pm-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

  public pageTitle : string ='forgotpwd';
  email:string;
  login: Login[];
 
  constructor(private forgtservice:frgtService) { }

  ngOnInit() {
  }
  saveAddr():void{
    alert('email:'+this.email)
    this.postAddr()
  }

  postAddr():void{
   
    this.forgtservice.postMail(this.email).subscribe(email=>this.email)
  }
}
