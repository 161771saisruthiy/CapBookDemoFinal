import  {  Injectable  }  from  "@angular/core";

import  {  HttpClient,  HttpErrorResponse,  HttpHeaders  }  from  "@angular/common/http";
import  {  Observable  }  from  "rxjs/Observable";
import  "rxjs/add/observable/throw";
import  "rxjs/add/operator/do";
import  "rxjs/add/operator/catch";
import { Email } from "./email";
import { Login } from "../loginpage/login";

const  httpOptions  = {
    headers: new  HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable()
export  class  frgtService {

    login = new Login()
    private forgotpassword: string = 'http://localhost:8083/forgetPwd/passwd/';
    //private email:Email[];

    constructor(private  _http: HttpClient) {

    }
    postMail(email: string): Observable<string> {
        this.forgotpassword = this.forgotpassword + email;
        return  this._http.post<string>(this.forgotpassword, email, {})
    }

}