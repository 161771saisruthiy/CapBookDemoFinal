import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-dummypage',
  templateUrl: './dummypage.component.html',
  styleUrls: ['./dummypage.component.css']
})
export class DummypageComponent implements OnInit {

  public pageTitle : string ='dummy';

  constructor() { }

  ngOnInit() {
  }

}
