import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-add-friend-comp',
  templateUrl: './add-friend-comp.component.html',
  styleUrls: ['./add-friend-comp.component.css']
})
export class AddFriendCompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
