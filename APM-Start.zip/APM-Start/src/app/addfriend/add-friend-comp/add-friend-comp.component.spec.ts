import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFriendCompComponent } from './add-friend-comp.component';

describe('AddFriendCompComponent', () => {
  let component: AddFriendCompComponent;
  let fixture: ComponentFixture<AddFriendCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddFriendCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddFriendCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
