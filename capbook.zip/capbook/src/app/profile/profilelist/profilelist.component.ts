import { Component, OnInit } from '@angular/core';
import { Profile } from '../../Model/app.model';

@Component({
  selector: 'app-profilelist',
  templateUrl: './profilelist.component.html',
  styleUrls: ['./profilelist.component.css']
})
export class ProfilelistComponent implements OnInit {

  profileList: Profile[] = [{
    
    fullName: "mark",
    photoPath:"assets/images/dp.jpg",
    description: "Software Engineer",
    relationship: "Single",
    mobileNo: 7306447896
  
  }
]
  constructor() { }

  ngOnInit() {
  }

}
