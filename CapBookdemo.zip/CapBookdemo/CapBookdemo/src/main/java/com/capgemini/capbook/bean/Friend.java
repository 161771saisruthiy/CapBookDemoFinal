package com.capgemini.capbook.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;

@Entity
public class Friend {
	
	@Id
	@GeneratedValue
	private Integer friendId;
	private Integer senderId;
	private Integer receiverId;
	private String status;
	@Lob
	private byte[] profilepic;

	
	public Friend() {
		
	}

	public Friend(Integer friendId, Integer senderId, Integer receiverId, String status) {
		super();
		this.friendId = friendId;
		this.senderId = senderId;
		this.receiverId = receiverId;
		this.status = status;
	}

	
	
	public Friend(Integer friendId, Integer receiverId, String status, byte[] profilepic) {
		super();
		this.friendId = friendId;
		this.receiverId = receiverId;
		this.status = status;
		this.profilepic = profilepic;
	}

	public Integer getFriendId() {
		return friendId;
	}

	public void setFriendId(Integer friendId) {
		this.friendId = friendId;
	}

	public Integer getSenderId() {
		return senderId;
	}

	public void setSenderId(Integer senderId) {
		this.senderId = senderId;
	}

	public Integer getReceiverId() {
		return receiverId;
	}

	public void setReceiverId(Integer receiverId) {
		this.receiverId = receiverId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public byte[] getProfilepic() {
		return profilepic;
	}

	public void setProfilepic(byte[] profilepic) {
		this.profilepic = profilepic;
	}

	
}
