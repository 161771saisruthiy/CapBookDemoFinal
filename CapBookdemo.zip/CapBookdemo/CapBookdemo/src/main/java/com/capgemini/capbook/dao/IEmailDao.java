package com.capgemini.capbook.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.capbook.bean.Email;

@Repository("emaildao")
@Transactional
public interface IEmailDao extends JpaRepository<Email, Integer> {

}
