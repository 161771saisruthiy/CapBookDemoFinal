package com.capgemini.capbook.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capbook.bean.Login;

@Repository("loginDao")
@Transactional
public interface ILoginDao extends JpaRepository<Login, String>{


    
    @Query("select l.email,l.password from Login l where l.email=:email and l.password=:password")
    public List<Login> findByUsernameAndPassword(@Param("email") String email,@Param("password") String password );

    
}
