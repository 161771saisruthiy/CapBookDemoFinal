package com.capgemini.capbook.dao;

import javax.transaction.Transactional;
import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capbook.bean.ChangePassword;

@Repository("psswdDao")
@Transactional

public interface IPasswdDao extends JpaRepository<ChangePassword, String>{
@Query("select l.password from Login l where l.email=:email")
public String getPassword(@Param("email") String mail);



@Query("select u.email from UserProfile u where u.userId=:userId")
public String getMail(@Param("userId") Integer userId);

@Query("select l.password from Login l where l.email=:email")
public String getPsswdBymail(@Param("email")String Email);

@Query(value="update ChangePassword set oldPassword=:Op,newPassword=:Np where emailId=:Email;",nativeQuery=true)
public String saveNewPasswd(@Param("Op")String Op,@Param("Np")String Np,@Param("Email")String mail);

}
