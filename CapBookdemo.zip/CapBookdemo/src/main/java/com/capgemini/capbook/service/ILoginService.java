package com.capgemini.capbook.service;

import com.capgemini.capbook.bean.Login;

public interface ILoginService {

	Boolean checkUser(Login login);
	
	

}
