package com.capgemini.capbook.dao;

import javax.transaction.Transactional;
import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capbook.bean.ChangePassword;

@Repository("psswdDao")
@Transactional

public interface IPasswdDao extends JpaRepository<ChangePassword, String>{
@Query("select l.password from Login l where l.email=:email")
public String getPassword(@Param("email") String mail);



@Query("select u.email from UserProfile u where u.userId=:userId")
public String getMail(@Param("userId") Integer userId);

@Query("select l.password from Login l where l.email=:email")
public String getPsswdBymail(@Param("email")String Email);

/*@Modifying
@Query("update ChangePassword set oldPassword=:oP,newPassword=:nP where emailId=:mail")
public Integer saveNewPasswd(@Param("oP")String Op,@Param("nP")String Np,@Param("mail")String mail);*/

//@Modifying
//@Query("insert into ChangePassword(emailId,oldPassword,newPassword) values(:email,:oP,:nP)")
//public Integer saveNewPasswd(@Param("oP")String Op,@Param("nP")String Np,@Param("email")String mail);

@Modifying
@Query("update Login set password=:psswd where email=:emailId")
public Integer saveLgnPasswd(@Param("psswd")String password,@Param("emailId")String email);

}
